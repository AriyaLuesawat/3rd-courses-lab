/* สำเนาที่ (ก) ตัดการตรวจสอบขอบเขตออก และ (ข) ใช้ n ที่หารด้วย 256 ไม่ลงตัว */
#include <cstdio>
#include <cstdlib>

__global__ void vecAdd(int n, const float *x, float *y) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    y[i] = x[i] + y[i];              /* ไม่มี if (i < n) */
}

int main() {
    const int n = 1000000;           /* 1,000,000 / 256 = 3906.25 -> ไม่ลงตัว */
    const size_t bytes = n * sizeof(float);

    float *d_x, *d_y;
    cudaMalloc(&d_x, bytes);
    cudaMalloc(&d_y, bytes);
    cudaMemset(d_x, 0, bytes);
    cudaMemset(d_y, 0, bytes);

    int threads = 256;
    int blocks  = (n + threads - 1) / threads;      /* = 3907 blocks */
    printf("threads ทั้งหมด = %d, n = %d, เธรดส่วนเกิน = %d\n",
           blocks * threads, n, blocks * threads - n);

    vecAdd<<<blocks, threads>>>(n, d_x, d_y);
    cudaDeviceSynchronize();

    cudaFree(d_x); cudaFree(d_y);
    return 0;
}
