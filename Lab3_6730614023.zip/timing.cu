#include <cstdio>
#include <chrono>

__global__ void vecAdd(int n, const float *x, float *y) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) y[i] = x[i] + y[i];
}

int main() {
    const int n = 1 << 24;
    const size_t bytes = n * sizeof(float);
    float *d_x, *d_y;
    cudaMalloc(&d_x, bytes); cudaMalloc(&d_y, bytes);
    cudaMemset(d_x, 0, bytes); cudaMemset(d_y, 0, bytes);

    int threads = 256, blocks = (n + threads - 1) / threads;
    vecAdd<<<blocks, threads>>>(n, d_x, d_y);      /* warm-up */
    cudaDeviceSynchronize();

    /* (1) chrono โดยไม่ซิงโครไนซ์ -- ผิด */
    auto t0 = std::chrono::steady_clock::now();
    for (int r = 0; r < 20; r++) vecAdd<<<blocks, threads>>>(n, d_x, d_y);
    auto t1 = std::chrono::steady_clock::now();
    double ms_wrong =
        std::chrono::duration<double, std::milli>(t1 - t0).count() / 20;

    /* (2) chrono พร้อมซิงโครไนซ์ -- ถูก */
    cudaDeviceSynchronize();
    t0 = std::chrono::steady_clock::now();
    for (int r = 0; r < 20; r++) vecAdd<<<blocks, threads>>>(n, d_x, d_y);
    cudaDeviceSynchronize();
    t1 = std::chrono::steady_clock::now();
    double ms_right =
        std::chrono::duration<double, std::milli>(t1 - t0).count() / 20;

    /* (3) CUDA events -- วิธีมาตรฐาน */
    cudaEvent_t s, e; float ms_ev = 0.0f;
    cudaEventCreate(&s); cudaEventCreate(&e);
    cudaEventRecord(s);
    for (int r = 0; r < 20; r++) vecAdd<<<blocks, threads>>>(n, d_x, d_y);
    cudaEventRecord(e); cudaEventSynchronize(e);
    cudaEventElapsedTime(&ms_ev, s, e); ms_ev /= 20.0f;

    printf("chrono ไม่ sync : %10.4f ms\n", ms_wrong);
    printf("chrono + sync   : %10.4f ms\n", ms_right);
    printf("CUDA events     : %10.4f ms\n", ms_ev);
    printf("อัตราส่วนผิดพลาด : %10.1f เท่า\n", ms_right / ms_wrong);

    cudaFree(d_x); cudaFree(d_y);
    return 0;
}
