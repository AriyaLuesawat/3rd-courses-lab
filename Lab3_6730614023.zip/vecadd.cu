#include <cstdio>
#include <cstdlib>
#include <cmath>

#define CUDA_CHECK(call)                                        \
  do {                                                          \
    cudaError_t err = (call);                                   \
    if (err != cudaSuccess) {                                   \
      fprintf(stderr, "CUDA %s:%d: %s\n", __FILE__, __LINE__,   \
              cudaGetErrorString(err));                         \
      exit(EXIT_FAILURE);                                       \
    }                                                           \
  } while (0)

__global__ void vecAdd(int n, const float *x, float *y) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) y[i] = x[i] + y[i];
}

int main() {
    const int n = 1 << 24;                     // 16.7 M
    const size_t bytes = n * sizeof(float);

    float *h_x = (float*)malloc(bytes);
    float *h_y = (float*)malloc(bytes);
    for (int i = 0; i < n; i++) { h_x[i] = 1.0f; h_y[i] = 2.0f; }

    float *d_x, *d_y;
    CUDA_CHECK(cudaMalloc(&d_x, bytes));
    CUDA_CHECK(cudaMalloc(&d_y, bytes));
    CUDA_CHECK(cudaMemcpy(d_x, h_x, bytes, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(d_y, h_y, bytes, cudaMemcpyHostToDevice));

    int threads = 256;
    int blocks  = (n + threads - 1) / threads;   // ปัดเศษขึ้นเสมอ

    cudaEvent_t start, stop; float ms = 0.0f;
    CUDA_CHECK(cudaEventCreate(&start));
    CUDA_CHECK(cudaEventCreate(&stop));

    vecAdd<<<blocks, threads>>>(n, d_x, d_y);    // warm-up
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());

    CUDA_CHECK(cudaEventRecord(start));
    for (int r = 0; r < 20; r++) {
        vecAdd<<<blocks, threads>>>(n, d_x, d_y);
        CUDA_CHECK(cudaGetLastError());
    }
    CUDA_CHECK(cudaEventRecord(stop));
    CUDA_CHECK(cudaEventSynchronize(stop));
    CUDA_CHECK(cudaEventElapsedTime(&ms, start, stop));
    ms /= 20.0f;

    CUDA_CHECK(cudaMemcpy(h_y, d_y, bytes, cudaMemcpyDeviceToHost));
    const float expected = 23.0f;  // เริ่มที่ 2 และบวก x=1 จำนวน 21 รอบ
    int errors = 0;
    for (int i = 0; i < n; i++) {
        if (fabsf(h_y[i] - expected) > 1e-5f) {
            if (errors < 5)
                fprintf(stderr, "mismatch at %d: got %.1f expected %.1f\n",
                        i, h_y[i], expected);
            errors++;
        }
    }
    printf("verification: %s (expected y[i] = %.1f)\n",
           errors == 0 ? "PASS" : "FAIL", expected);

    double gbps = 12.0 * n / (ms * 1e-3) / 1e9;
    printf("vecAdd : %8.3f ms   %7.1f GB/s   %5.1f%% of Lab 2\n",
           ms, gbps, gbps / 241.0 * 100.0);

    CUDA_CHECK(cudaEventDestroy(start));
    CUDA_CHECK(cudaEventDestroy(stop));
    CUDA_CHECK(cudaFree(d_x));
    CUDA_CHECK(cudaFree(d_y));
    free(h_x);
    free(h_y);
    return 0;
}
