#include <cstdio>

__global__ void hello() {
    printf("block %d, thread %d\n", blockIdx.x, threadIdx.x);
}

int main() {
    hello<<<2, 4>>>();        /* 2 blocks x 4 threads */
    cudaDeviceSynchronize();  /* without this, main() may */
    return 0;                 /* exit before the GPU prints */
}
