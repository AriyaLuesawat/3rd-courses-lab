#include <cstdio>
#include <cstdlib>

#define CUDA_CHECK(call)                                        \
  do {                                                          \
    cudaError_t err = (call);                                   \
    if (err != cudaSuccess) {                                   \
      fprintf(stderr, "CUDA %s:%d: %s\n", __FILE__, __LINE__,   \
              cudaGetErrorString(err));                         \
      exit(EXIT_FAILURE);                                       \
    }                                                           \
  } while (0)

__global__ void saxpy(int n, float a, const float *x, float *y) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) y[i] = a * x[i] + y[i];
}

int main() {
    const int n = 1 << 26;                 /* 67 ล้านตัว = 268 MB ต่อ array */
    const size_t bytes = (size_t)n * sizeof(float);
    float *dx, *dy;
    CUDA_CHECK(cudaMalloc(&dx, bytes)); CUDA_CHECK(cudaMalloc(&dy, bytes));
    CUDA_CHECK(cudaMemset(dx, 0, bytes)); CUDA_CHECK(cudaMemset(dy, 0, bytes));

    int sizes[] = {32, 64, 96, 128, 256, 512, 1024};
    printf("  block   grid      เวลา (ms)    GB/s    occupancy (blocks/SM)\n");
    for (int s = 0; s < 7; s++) {
        int blk = sizes[s], grd = (n + blk - 1) / blk;
        int maxBlocks = 0;
        CUDA_CHECK(cudaOccupancyMaxActiveBlocksPerMultiprocessor(
                       &maxBlocks, saxpy, blk, 0));
        cudaEvent_t e0, e1; float ms = 0.0f;
        CUDA_CHECK(cudaEventCreate(&e0)); CUDA_CHECK(cudaEventCreate(&e1));
        for (int r = 0; r < 11; r++) {
            if (r == 1) CUDA_CHECK(cudaEventRecord(e0));
            saxpy<<<grd, blk>>>(n, 2.0f, dx, dy);
        }
        CUDA_CHECK(cudaEventRecord(e1));
        CUDA_CHECK(cudaEventSynchronize(e1));
        CUDA_CHECK(cudaEventElapsedTime(&ms, e0, e1));
        CUDA_CHECK(cudaGetLastError());
        ms /= 10.0f;
        double gb = 12.0 * n / 1e9;        /* อ่าน x, อ่าน y, เขียน y = 12 ไบต์ */
        printf("  %5d %7d   %9.3f  %7.1f    %d blocks (%d threads)\n",
               blk, grd, ms, gb / (ms/1e3), maxBlocks, maxBlocks * blk);
        CUDA_CHECK(cudaEventDestroy(e0)); CUDA_CHECK(cudaEventDestroy(e1));
    }
    CUDA_CHECK(cudaFree(dx)); CUDA_CHECK(cudaFree(dy));
    return 0;
}
