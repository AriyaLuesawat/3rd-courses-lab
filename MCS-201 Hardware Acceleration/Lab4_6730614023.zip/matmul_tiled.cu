#include <cstdio>
#include <cstdlib>
#include <cmath>

#define CUDA_CHECK(call)                                        \
  do {                                                          \
    cudaError_t err = (call);                                   \
    if (err != cudaSuccess) {                                   \
      fprintf(stderr, "CUDA %s:%d: %s\n", __FILE__, __LINE__,   \
              cudaGetErrorString(err));                         \
      exit(EXIT_FAILURE);                                       \
    }                                                           \
  } while (0)

#define T 16

/* ---- baseline จาก Lab 3 (ให้มาแล้ว ห้ามแก้) ---------------------- */
__global__ void matmulNaive(int N, const float *A, const float *B, float *C) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;
    if (row < N && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < N; k++) sum += A[row*N + k] * B[k*N + col];
        C[row*N + col] = sum;
    }
}

/* ---- ส่วนที่ต้องเขียนเอง ---------------------------------------- */
__global__ void matmulTiled(int N, const float *A, const float *B, float *C) {
    __shared__ float As[T][T];
    __shared__ float Bs[T][T];

    int tx = threadIdx.x, ty = threadIdx.y;
    int row = blockIdx.y * T + ty;
    int col = blockIdx.x * T + tx;
    float sum = 0.0f;

    for (int t = 0; t < (N + T - 1) / T; t++) {
        int aCol = t * T + tx;
        int bRow = t * T + ty;

        /* TODO (1): โหลด A หนึ่งช่องลง As[ty][tx]
                     ถ้า row หรือ aCol เกินขอบเขต ให้ใส่ 0.0f */
        As[ty][tx] = (row < N && aCol < N) ? A[row*N + aCol] : 0.0f;

        /* TODO (2): โหลด B หนึ่งช่องลง Bs[ty][tx] ในทำนองเดียวกัน */
        Bs[ty][tx] = (bRow < N && col < N) ? B[bRow*N + col] : 0.0f;

        /* TODO (3): barrier ตัวที่หนึ่ง — กันไม่ให้ใครอ่านไทล์ก่อนเขียนเสร็จ */
        __syncthreads();

        for (int k = 0; k < T; k++) {
            /* TODO (4): สะสมผลคูณจาก shared memory ลงใน sum */
            sum += As[ty][k] * Bs[k][tx];
        }

        /* TODO (5): barrier ตัวที่สอง — กันไม่ให้ใครเขียนทับไทล์ที่ยังมีคนอ่าน */
        __syncthreads();
    }
    if (row < N && col < N) C[row*N + col] = sum;
}

/* ---- host code (ให้มาแล้ว) -------------------------------------- */
static float timeKernel(void (*launch)(int, const float*, const float*, float*),
                        int N, const float *dA, const float *dB, float *dC) {
    cudaEvent_t s, e; float ms = 0.0f;
    CUDA_CHECK(cudaEventCreate(&s)); CUDA_CHECK(cudaEventCreate(&e));
    launch(N, dA, dB, dC);                       /* warm-up */
    CUDA_CHECK(cudaDeviceSynchronize());
    CUDA_CHECK(cudaEventRecord(s));
    for (int r = 0; r < 5; r++) launch(N, dA, dB, dC);
    CUDA_CHECK(cudaEventRecord(e));
    CUDA_CHECK(cudaEventSynchronize(e));
    CUDA_CHECK(cudaEventElapsedTime(&ms, s, e));
    CUDA_CHECK(cudaEventDestroy(s)); CUDA_CHECK(cudaEventDestroy(e));
    return ms / 5.0f;
}

static void launchNaive(int N, const float *A, const float *B, float *C) {
    dim3 blk(T, T), grd((N + T - 1)/T, (N + T - 1)/T);
    matmulNaive<<<grd, blk>>>(N, A, B, C);
}
static void launchTiled(int N, const float *A, const float *B, float *C) {
    dim3 blk(T, T), grd((N + T - 1)/T, (N + T - 1)/T);
    matmulTiled<<<grd, blk>>>(N, A, B, C);
}

int main(int argc, char **argv) {
    int N = (argc > 1) ? atoi(argv[1]) : 1024;
    size_t bytes = (size_t)N * N * sizeof(float);

    float *hA = (float*)malloc(bytes), *hB = (float*)malloc(bytes),
          *hC = (float*)malloc(bytes);
    for (int i = 0; i < N*N; i++) { hA[i] = 1.0f; hB[i] = 2.0f; }

    float *dA, *dB, *dC;
    CUDA_CHECK(cudaMalloc(&dA, bytes)); CUDA_CHECK(cudaMalloc(&dB, bytes));
    CUDA_CHECK(cudaMalloc(&dC, bytes));
    CUDA_CHECK(cudaMemcpy(dA, hA, bytes, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(dB, hB, bytes, cudaMemcpyHostToDevice));

    float tn = timeKernel(launchNaive, N, dA, dB, dC);
    float tt = timeKernel(launchTiled, N, dA, dB, dC);

    CUDA_CHECK(cudaMemcpy(hC, dC, bytes, cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaGetLastError());
    double expect = 2.0 * N, maxerr = 0.0;
    for (int i = 0; i < N*N; i++) maxerr = fmax(maxerr, fabs(hC[i] - expect));

    double gflop = 2.0 * N * N * N / 1e9;
    printf("N = %d   ตรวจความถูกต้อง: ค่าที่ควรได้ %.1f  ค่าคลาดเคลื่อนสูงสุด %.3f  %s\n",
           N, expect, maxerr, (maxerr < 1e-2) ? "[ผ่าน]" : "[ไม่ผ่าน]");
    printf("  naive : %8.3f ms   %6.3f TFLOPS\n", tn, gflop / tn);
    printf("  tiled : %8.3f ms   %6.3f TFLOPS   speedup = %.2fx\n",
           tt, gflop / tt, tn / tt);

    free(hA); free(hB); free(hC);
    CUDA_CHECK(cudaFree(dA)); CUDA_CHECK(cudaFree(dB)); CUDA_CHECK(cudaFree(dC));
    return 0;
}
