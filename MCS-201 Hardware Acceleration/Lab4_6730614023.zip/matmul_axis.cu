#include <cstdio>
#include <cstdlib>
#include <cmath>

#define CUDA_CHECK(call)                                        \
  do {                                                          \
    cudaError_t err = (call);                                   \
    if (err != cudaSuccess) {                                   \
      fprintf(stderr, "CUDA %s:%d: %s\n", __FILE__, __LINE__,   \
              cudaGetErrorString(err));                         \
      exit(EXIT_FAILURE);                                       \
    }                                                           \
  } while (0)

#define T 32

/* (ก) ไทล์ 32 แบบปกติ: tx -> คอลัมน์ (แกนที่เปลี่ยนเร็วที่สุด) */
__global__ void tiled32(int N, const float *A, const float *B, float *C) {
    __shared__ float As[T][T], Bs[T][T];
    int tx = threadIdx.x, ty = threadIdx.y;
    int row = blockIdx.y*T + ty, col = blockIdx.x*T + tx;
    float sum = 0.0f;
    for (int t = 0; t < N/T; t++) {
        As[ty][tx] = A[row*N + (t*T + tx)];
        Bs[ty][tx] = B[(t*T + ty)*N + col];
        __syncthreads();
        for (int k = 0; k < T; k++) sum += As[ty][k] * Bs[k][tx];
        __syncthreads();
    }
    C[row*N + col] = sum;
}

/* (ข) สลับแกน: tx -> แถว  ผลลัพธ์ถูกต้องเหมือนเดิมทุกประการ */
__global__ void tiled32Swapped(int N, const float *A, const float *B, float *C) {
    __shared__ float As[T][T], Bs[T][T];
    int tx = threadIdx.x, ty = threadIdx.y;
    int row = blockIdx.y*T + tx;            /* <-- สลับ */
    int col = blockIdx.x*T + ty;            /* <-- สลับ */
    float sum = 0.0f;
    for (int t = 0; t < N/T; t++) {
        As[tx][ty] = A[row*N + (t*T + ty)];
        Bs[tx][ty] = B[(t*T + tx)*N + col];
        __syncthreads();
        for (int k = 0; k < T; k++) sum += As[tx][k] * Bs[k][ty];
        __syncthreads();
    }
    C[row*N + col] = sum;
}

static float timeIt(int which, int N, const float *dA, const float *dB, float *dC) {
    dim3 blk(T, T), grd(N/T, N/T);
    cudaEvent_t s, e; float ms = 0.0f;
    CUDA_CHECK(cudaEventCreate(&s)); CUDA_CHECK(cudaEventCreate(&e));
    for (int r = 0; r < 6; r++) {
        if (r == 1) CUDA_CHECK(cudaEventRecord(s));   /* r = 0 คือ warm-up */
        if (which == 0) tiled32<<<grd, blk>>>(N, dA, dB, dC);
        else            tiled32Swapped<<<grd, blk>>>(N, dA, dB, dC);
    }
    CUDA_CHECK(cudaEventRecord(e));
    CUDA_CHECK(cudaEventSynchronize(e));
    CUDA_CHECK(cudaEventElapsedTime(&ms, s, e));
    CUDA_CHECK(cudaGetLastError());
    return ms / 5.0f;
}

int main(int argc, char **argv) {
    int N = (argc > 1) ? atoi(argv[1]) : 2048;
    size_t bytes = (size_t)N * N * sizeof(float);
    float *hA = (float*)malloc(bytes), *hB = (float*)malloc(bytes),
          *hC = (float*)malloc(bytes);
    for (int i = 0; i < N*N; i++) { hA[i] = 1.0f; hB[i] = 2.0f; }
    float *dA, *dB, *dC;
    CUDA_CHECK(cudaMalloc(&dA, bytes)); CUDA_CHECK(cudaMalloc(&dB, bytes));
    CUDA_CHECK(cudaMalloc(&dC, bytes));
    CUDA_CHECK(cudaMemcpy(dA, hA, bytes, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(dB, hB, bytes, cudaMemcpyHostToDevice));

    float t0 = timeIt(0, N, dA, dB, dC);
    float t1 = timeIt(1, N, dA, dB, dC);
    CUDA_CHECK(cudaMemcpy(hC, dC, bytes, cudaMemcpyDeviceToHost));
    double expect = 2.0 * N, maxerr = 0.0;
    for (int i = 0; i < N*N; i++) maxerr = fmax(maxerr, fabs(hC[i] - expect));
    double gflop = 2.0 * N * N * N / 1e9;

    printf("N = %d   ค่าคลาดเคลื่อนสูงสุด %.3f  %s\n",
           N, maxerr, (maxerr < 1e-2) ? "[ผ่าน]" : "[ไม่ผ่าน]");
    printf("  tiled32          : %8.3f ms   %6.3f TFLOPS\n", t0, gflop/t0);
    printf("  tiled32 สลับแกน  : %8.3f ms   %6.3f TFLOPS   ช้าลง %.2f เท่า\n",
           t1, gflop/t1, t1/t0);
    free(hA); free(hB); free(hC);
    CUDA_CHECK(cudaFree(dA)); CUDA_CHECK(cudaFree(dB)); CUDA_CHECK(cudaFree(dC));
    return 0;
}
