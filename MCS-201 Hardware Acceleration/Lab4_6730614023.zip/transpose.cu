#include <cstdio>
#include <cstdlib>
#include <cmath>

#define CUDA_CHECK(call)                                        \
  do {                                                          \
    cudaError_t err = (call);                                   \
    if (err != cudaSuccess) {                                   \
      fprintf(stderr, "CUDA %s:%d: %s\n", __FILE__, __LINE__,   \
              cudaGetErrorString(err));                         \
      exit(EXIT_FAILURE);                                       \
    }                                                           \
  } while (0)

#define TILE 32
#define ROWS 8              /* แต่ละเธรดจัดการ 4 แถว: 32x8 = 256 เธรดต่อ block */

/* (ก) ไม่ใช้ shared memory เลย: การเขียนมี stride = N */
__global__ void transposeNaive(int N, const float *in, float *out) {
    int x = blockIdx.x*TILE + threadIdx.x;
    int y = blockIdx.y*TILE + threadIdx.y;
    for (int j = 0; j < TILE; j += ROWS)
        out[x*N + (y+j)] = in[(y+j)*N + x];
}

/* (ข) ใช้ไทล์ [32][32] — อ่านตามแนวตั้งของไทล์ */
__global__ void transposeTile(int N, const float *in, float *out) {
    __shared__ float tile[TILE][TILE];
    int x = blockIdx.x*TILE + threadIdx.x;
    int y = blockIdx.y*TILE + threadIdx.y;
    for (int j = 0; j < TILE; j += ROWS)
        tile[threadIdx.y + j][threadIdx.x] = in[(y+j)*N + x];
    __syncthreads();
    x = blockIdx.y*TILE + threadIdx.x;
    y = blockIdx.x*TILE + threadIdx.y;
    for (int j = 0; j < TILE; j += ROWS)
        out[(y+j)*N + x] = tile[threadIdx.x][threadIdx.y + j];   /* แนวตั้ง */
}

/* (ค) ไทล์เดียวกัน เพิ่ม padding หนึ่งคอลัมน์ */
__global__ void transposeTilePad(int N, const float *in, float *out) {
    __shared__ float tile[TILE][TILE + 1];        /* <-- ต่างกันแค่ตรงนี้ */
    int x = blockIdx.x*TILE + threadIdx.x;
    int y = blockIdx.y*TILE + threadIdx.y;
    for (int j = 0; j < TILE; j += ROWS)
        tile[threadIdx.y + j][threadIdx.x] = in[(y+j)*N + x];
    __syncthreads();
    x = blockIdx.y*TILE + threadIdx.x;
    y = blockIdx.x*TILE + threadIdx.y;
    for (int j = 0; j < TILE; j += ROWS)
        out[(y+j)*N + x] = tile[threadIdx.x][threadIdx.y + j];
}

static float timeIt(int which, int N, const float *d_in, float *d_out) {
    dim3 blk(TILE, ROWS), grd(N/TILE, N/TILE);
    cudaEvent_t s, e; float ms = 0.0f;
    CUDA_CHECK(cudaEventCreate(&s)); CUDA_CHECK(cudaEventCreate(&e));
    for (int r = 0; r < 21; r++) {
        if (r == 1) CUDA_CHECK(cudaEventRecord(s));
        if      (which == 0) transposeNaive  <<<grd, blk>>>(N, d_in, d_out);
        else if (which == 1) transposeTile   <<<grd, blk>>>(N, d_in, d_out);
        else                 transposeTilePad<<<grd, blk>>>(N, d_in, d_out);
    }
    CUDA_CHECK(cudaEventRecord(e));
    CUDA_CHECK(cudaEventSynchronize(e));
    CUDA_CHECK(cudaEventElapsedTime(&ms, s, e));
    CUDA_CHECK(cudaGetLastError());
    return ms / 20.0f;
}

int main(int argc, char **argv) {
    int N = (argc > 1) ? atoi(argv[1]) : 4096;
    size_t bytes = (size_t)N * N * sizeof(float);
    float *h_in = (float*)malloc(bytes), *h_out = (float*)malloc(bytes);
    for (int i = 0; i < N*N; i++) h_in[i] = (float)i;

    float *d_in, *d_out;
    CUDA_CHECK(cudaMalloc(&d_in, bytes)); CUDA_CHECK(cudaMalloc(&d_out, bytes));
    CUDA_CHECK(cudaMemcpy(d_in, h_in, bytes, cudaMemcpyHostToDevice));

    const char *name[3] = {"naive (ไม่ใช้ shared)", "tile [32][32]      ",
                           "tile [32][33] padded"};
    float t[3];
    for (int w = 0; w < 3; w++) {
        t[w] = timeIt(w, N, d_in, d_out);
        CUDA_CHECK(cudaMemcpy(h_out, d_out, bytes, cudaMemcpyDeviceToHost));
        int ok = 1;
        for (int i = 0; i < N && ok; i++)
            for (int j = 0; j < N; j++)
                if (h_out[j*N + i] != h_in[i*N + j]) { ok = 0; break; }
        /* ย้ายข้อมูล 2 ครั้ง (อ่าน + เขียน) => แบนด์วิดท์ที่ทำได้ */
        double gb = 2.0 * bytes / 1e9;
        printf("  %s : %7.3f ms   %6.1f GB/s   %s\n",
               name[w], t[w], gb / (t[w]/1e3), ok ? "[ผ่าน]" : "[ไม่ผ่าน]");
    }
    printf("\n  อัตราส่วน [32][32] / [32][33] = %.2f เท่า\n", t[1] / t[2]);

    free(h_in); free(h_out);
    CUDA_CHECK(cudaFree(d_in)); CUDA_CHECK(cudaFree(d_out));
    return 0;
}
