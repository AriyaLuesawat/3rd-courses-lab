/* app.cu — โปรแกรมประมวลผล "เฟรม" แบบที่เขียนตามสัญชาตญาณ (ถูกต้อง แต่ช้า)
   ห้ามแก้ไฟล์นี้ — ใช้เป็น baseline สำหรับ Nsight Systems                  */
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <nvtx3/nvToolsExt.h>

#define CUDA_CHECK(call)                                        \
  do {                                                          \
    cudaError_t err = (call);                                   \
    if (err != cudaSuccess) {                                   \
      fprintf(stderr, "CUDA %s:%d: %s\n", __FILE__, __LINE__,   \
              cudaGetErrorString(err));                         \
      exit(EXIT_FAILURE);                                       \
    }                                                           \
  } while (0)

const int FRAMES = 16;
const int NPIX   = 1 << 22;                 /* 4M float = 16 MB ต่อเฟรม */

__global__ void normalize(int n, const float *in, float *out, float mean, float inv) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) out[i] = (in[i] - mean) * inv;
}
__global__ void gammaClamp(int n, float *x, float g) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) x[i] = powf(fminf(fmaxf(x[i], 0.0f), 1.0f), g);
}

static void fillFrame(float *h, int f) {             /* งานฝั่ง CPU: "อ่านเฟรม" */
    for (int i = 0; i < NPIX; i++) h[i] = (float)((i * 7 + f * 13) % 1000);
}
static double checksum(const float *h) {             /* งานฝั่ง CPU: "ตรวจเฟรม" */
    double s = 0.0;
    for (int i = 0; i < NPIX; i++) s += h[i];
    return s;
}

int main() {
    size_t bytes = (size_t)NPIX * sizeof(float);
    double sums[FRAMES];

    nvtxRangePushA("init");
    CUDA_CHECK(cudaFree(0));                          /* สร้าง CUDA context ตรงนี้ */
    nvtxRangePop();

    auto t0 = std::chrono::steady_clock::now();
    for (int f = 0; f < FRAMES; f++) {
        nvtxRangePushA("frame");

        nvtxRangePushA("cpu: fill");
        float *h_in  = (float*)malloc(bytes);         /* pageable memory */
        float *h_out = (float*)malloc(bytes);
        fillFrame(h_in, f);
        nvtxRangePop();

        float *d_in, *d_out;
        CUDA_CHECK(cudaMalloc(&d_in, bytes));         /* จองใหม่ทุกเฟรม */
        CUDA_CHECK(cudaMalloc(&d_out, bytes));

        CUDA_CHECK(cudaMemcpy(d_in, h_in, bytes, cudaMemcpyHostToDevice));
        normalize <<<(NPIX + 255) / 256, 256>>>(NPIX, d_in, d_out, 500.0f, 1.0f / 1000.0f);
        gammaClamp<<<(NPIX + 255) / 256, 256>>>(NPIX, d_out, 1.0f / 2.2f);
        CUDA_CHECK(cudaGetLastError());
        CUDA_CHECK(cudaMemcpy(h_out, d_out, bytes, cudaMemcpyDeviceToHost));
        CUDA_CHECK(cudaDeviceSynchronize());

        CUDA_CHECK(cudaFree(d_in));
        CUDA_CHECK(cudaFree(d_out));

        nvtxRangePushA("cpu: checksum");
        sums[f] = checksum(h_out);
        free(h_in); free(h_out);
        nvtxRangePop();

        nvtxRangePop();                               /* frame */
    }
    auto t1 = std::chrono::steady_clock::now();

    double total = 0.0;
    for (int f = 0; f < FRAMES; f++) total += sums[f];
    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    printf("app       : %d เฟรม  %8.1f ms  (%.2f ms/เฟรม)  checksum = %.6e\n",
           FRAMES, ms, ms / FRAMES, total);
    return 0;
}
