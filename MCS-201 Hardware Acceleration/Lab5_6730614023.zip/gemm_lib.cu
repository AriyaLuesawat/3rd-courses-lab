#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <chrono>
#include <cublas_v2.h>

#define CUDA_CHECK(call)                                        \
  do {                                                          \
    cudaError_t err = (call);                                   \
    if (err != cudaSuccess) {                                   \
      fprintf(stderr, "CUDA %s:%d: %s\n", __FILE__, __LINE__,   \
              cudaGetErrorString(err));                         \
      exit(EXIT_FAILURE);                                       \
    }                                                           \
  } while (0)

#define CUBLAS_CHECK(call)                                      \
  do {                                                          \
    cublasStatus_t st = (call);                                 \
    if (st != CUBLAS_STATUS_SUCCESS) {                          \
      fprintf(stderr, "cuBLAS %s:%d: status %d\n",              \
              __FILE__, __LINE__, (int)st);                     \
      exit(EXIT_FAILURE);                                       \
    }                                                           \
  } while (0)

#define T 32

/* ---- tiled matmul T = 32 จากเฉลย Lab 4 (ให้มาแล้ว ห้ามแก้) ------------ */
__global__ void tiled32(int N, const float *A, const float *B, float *C) {
    __shared__ float As[T][T], Bs[T][T];
    int tx = threadIdx.x, ty = threadIdx.y;
    int row = blockIdx.y*T + ty, col = blockIdx.x*T + tx;
    float sum = 0.0f;
    for (int t = 0; t < N/T; t++) {
        As[ty][tx] = A[row*N + (t*T + tx)];
        Bs[ty][tx] = B[(t*T + ty)*N + col];
        __syncthreads();
        for (int k = 0; k < T; k++) sum += As[ty][k] * Bs[k][tx];
        __syncthreads();
    }
    C[row*N + col] = sum;
}

/* ---- cuBLAS: C = A * B โดยที่ A, B, C เก็บแบบ row-major ---------------- */
static void gemmCublas(cublasHandle_t h, int N,
                       const float *A, const float *B, float *C) {
    const float alpha = 1.0f, beta = 0.0f;
    /* TODO (1): บรรทัดด้านล่างเขียนแบบ "ตรงไปตรงมา" คือส่ง A ก่อน B
       รันแล้วจะได้ [ไม่ผ่าน] เพราะ cuBLAS มองหน่วยความจำเป็น column-major
       ให้แก้เฉพาะลำดับของ matrix ที่ส่งเข้าไป โดยห้าม transpose ข้อมูลและห้ามใช้ CUBLAS_OP_T
       (คำใบ้: หน่วยความจำของ A แบบ row-major = A^T แบบ column-major และ (AB)^T = B^T A^T)  */
    CUBLAS_CHECK(cublasSgemm(h, CUBLAS_OP_N, CUBLAS_OP_N,
                             N, N, N,
                             &alpha,
                             B, N,        /* TODO (1) เมทริกซ์ตัวแรก   */
                             A, N,        /* TODO (1) เมทริกซ์ตัวที่สอง */
                             &beta,
                             C, N));
}

/* ---- ตรวจความถูกต้องแบบสุ่ม 256 ตำแหน่ง เทียบกับ CPU (double) ------------ */
static bool check(int N, const float *A, const float *B, const float *C) {
    srand(7);
    for (int s = 0; s < 256; s++) {
        int i = rand() % N, j = rand() % N;
        double ref = 0.0, mag = 0.0;
        for (int k = 0; k < N; k++) {
            ref += (double)A[i*N + k] * B[k*N + j];
            mag += fabs((double)A[i*N + k] * B[k*N + j]);
        }
        if (fabs(C[i*N + j] - ref) > 1e-4 * mag + 1e-5) {
            printf("    ผิดที่ C[%d][%d]: ได้ %.5f ควรได้ %.5f\n", i, j, C[i*N + j], ref);
            return false;
        }
    }
    return true;
}

int main(int argc, char **argv) {
    int N = (argc > 1) ? atoi(argv[1]) : 2048;          /* ต้องหารด้วย 32 ลงตัว */
    size_t bytes = (size_t)N * N * sizeof(float);
    float *hA = (float*)malloc(bytes), *hB = (float*)malloc(bytes),
          *hC = (float*)malloc(bytes);
    srand(1);
    for (int i = 0; i < N*N; i++) {
        hA[i] = 2.0f * rand() / RAND_MAX - 1.0f;
        hB[i] = 2.0f * rand() / RAND_MAX - 1.0f;
    }
    float *dA, *dB, *dC;
    CUDA_CHECK(cudaMalloc(&dA, bytes)); CUDA_CHECK(cudaMalloc(&dB, bytes));
    CUDA_CHECK(cudaMalloc(&dC, bytes));
    CUDA_CHECK(cudaMemcpy(dA, hA, bytes, cudaMemcpyHostToDevice));
    CUDA_CHECK(cudaMemcpy(dB, hB, bytes, cudaMemcpyHostToDevice));

    /* สร้าง handle ครั้งเดียว — จับเวลาไว้ให้เห็นว่าแพงแค่ไหน */
    auto h0 = std::chrono::steady_clock::now();
    cublasHandle_t handle;
    CUBLAS_CHECK(cublasCreate(&handle));
    auto h1 = std::chrono::steady_clock::now();
    double createMs = std::chrono::duration<double, std::milli>(h1 - h0).count();

    cudaEvent_t s, e;
    CUDA_CHECK(cudaEventCreate(&s)); CUDA_CHECK(cudaEventCreate(&e));
    const int REPS = 10;
    double gflop = 2.0 * N * N * N / 1e9;
    float ms[2];
    const char *name[2] = {"tiled32 (Lab 4)", "cuBLAS SGEMM   "};

    for (int w = 0; w < 2; w++) {
        CUDA_CHECK(cudaMemset(dC, 0, bytes));
        for (int r = 0; r <= REPS; r++) {
            if (r == 1) CUDA_CHECK(cudaEventRecord(s));       /* r = 0 คือ warm-up */
            if (w == 0) tiled32<<<dim3(N/T, N/T), dim3(T, T)>>>(N, dA, dB, dC);
            else        gemmCublas(handle, N, dA, dB, dC);
        }
        CUDA_CHECK(cudaEventRecord(e));
        CUDA_CHECK(cudaEventSynchronize(e));
        CUDA_CHECK(cudaGetLastError());
        CUDA_CHECK(cudaEventElapsedTime(&ms[w], s, e));
        ms[w] /= REPS;
        CUDA_CHECK(cudaMemcpy(hC, dC, bytes, cudaMemcpyDeviceToHost));
        bool ok = check(N, hA, hB, hC);
        printf("  %s : %8.3f ms   %6.3f TFLOPS   %s\n",
               name[w], ms[w], gflop / ms[w], ok ? "[ผ่าน]" : "[ไม่ผ่าน]");
    }
    printf("  cuBLAS เร็วกว่า tiled32 = %.2f เท่า   (N = %d)\n", ms[0] / ms[1], N);
    printf("  เวลาสร้าง cublasHandle = %.1f ms (ครั้งเดียวต่อโปรแกรม)\n", createMs);

    CUBLAS_CHECK(cublasDestroy(handle));
    CUDA_CHECK(cudaEventDestroy(s)); CUDA_CHECK(cudaEventDestroy(e));
    free(hA); free(hB); free(hC);
    CUDA_CHECK(cudaFree(dA)); CUDA_CHECK(cudaFree(dB)); CUDA_CHECK(cudaFree(dC));
    return 0;
}
