/* kernels.cu — kernel ที่ท่านรู้จักแล้วจาก Lab 3–4 รวมไว้ในไฟล์เดียวเพื่อส่งให้ Nsight Compute
   แต่ละ kernel ถูกเรียกเพียงครั้งเดียว (ncu จะ replay ซ้ำเองหลายรอบเพื่อเก็บ counter)        */
#include <cstdio>
#include <cstdlib>

#define CUDA_CHECK(call)                                        \
  do {                                                          \
    cudaError_t err = (call);                                   \
    if (err != cudaSuccess) {                                   \
      fprintf(stderr, "CUDA %s:%d: %s\n", __FILE__, __LINE__,   \
              cudaGetErrorString(err));                         \
      exit(EXIT_FAILURE);                                       \
    }                                                           \
  } while (0)

#define T 32
#define TILE 32
#define ROWS 8

/* Lab 3: naive matmul (block 16x16) */
__global__ void matmulNaive(int N, const float *A, const float *B, float *C) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;
    if (row < N && col < N) {
        float sum = 0.0f;
        for (int k = 0; k < N; k++) sum += A[row*N + k] * B[k*N + col];
        C[row*N + col] = sum;
    }
}

/* Lab 4 ส่วนที่ 2 (ก): tiled T = 32 */
__global__ void tiled32(int N, const float *A, const float *B, float *C) {
    __shared__ float As[T][T], Bs[T][T];
    int tx = threadIdx.x, ty = threadIdx.y;
    int row = blockIdx.y*T + ty, col = blockIdx.x*T + tx;
    float sum = 0.0f;
    for (int t = 0; t < N/T; t++) {
        As[ty][tx] = A[row*N + (t*T + tx)];
        Bs[ty][tx] = B[(t*T + ty)*N + col];
        __syncthreads();
        for (int k = 0; k < T; k++) sum += As[ty][k] * Bs[k][tx];
        __syncthreads();
    }
    C[row*N + col] = sum;
}

/* Lab 4 ส่วนที่ 2 (ข): tiled T = 32 สลับแกน */
__global__ void tiled32Swapped(int N, const float *A, const float *B, float *C) {
    __shared__ float As[T][T], Bs[T][T];
    int tx = threadIdx.x, ty = threadIdx.y;
    int row = blockIdx.y*T + tx;
    int col = blockIdx.x*T + ty;
    float sum = 0.0f;
    for (int t = 0; t < N/T; t++) {
        As[tx][ty] = A[row*N + (t*T + ty)];
        Bs[tx][ty] = B[(t*T + tx)*N + col];
        __syncthreads();
        for (int k = 0; k < T; k++) sum += As[tx][k] * Bs[k][ty];
        __syncthreads();
    }
    C[row*N + col] = sum;
}

/* Lab 4 ส่วนที่ 3: transpose ไทล์ [32][32] และ [32][33] */
__global__ void transposeTile(int N, const float *in, float *out) {
    __shared__ float tile[TILE][TILE];
    int x = blockIdx.x*TILE + threadIdx.x;
    int y = blockIdx.y*TILE + threadIdx.y;
    for (int j = 0; j < TILE; j += ROWS)
        tile[threadIdx.y + j][threadIdx.x] = in[(y+j)*N + x];
    __syncthreads();
    x = blockIdx.y*TILE + threadIdx.x;
    y = blockIdx.x*TILE + threadIdx.y;
    for (int j = 0; j < TILE; j += ROWS)
        out[(y+j)*N + x] = tile[threadIdx.x][threadIdx.y + j];
}
__global__ void transposeTilePad(int N, const float *in, float *out) {
    __shared__ float tile[TILE][TILE + 1];
    int x = blockIdx.x*TILE + threadIdx.x;
    int y = blockIdx.y*TILE + threadIdx.y;
    for (int j = 0; j < TILE; j += ROWS)
        tile[threadIdx.y + j][threadIdx.x] = in[(y+j)*N + x];
    __syncthreads();
    x = blockIdx.y*TILE + threadIdx.x;
    y = blockIdx.x*TILE + threadIdx.y;
    for (int j = 0; j < TILE; j += ROWS)
        out[(y+j)*N + x] = tile[threadIdx.x][threadIdx.y + j];
}

int main(int argc, char **argv) {
    int N  = (argc > 1) ? atoi(argv[1]) : 1024;       /* matmul N x N    */
    int NT = (argc > 2) ? atoi(argv[2]) : 4096;       /* transpose NT x NT */
    size_t mb = (size_t)N * N * sizeof(float), tb = (size_t)NT * NT * sizeof(float);
    float *dA, *dB, *dC, *dI, *dO;
    CUDA_CHECK(cudaMalloc(&dA, mb)); CUDA_CHECK(cudaMalloc(&dB, mb));
    CUDA_CHECK(cudaMalloc(&dC, mb));
    CUDA_CHECK(cudaMalloc(&dI, tb)); CUDA_CHECK(cudaMalloc(&dO, tb));
    CUDA_CHECK(cudaMemset(dA, 0, mb)); CUDA_CHECK(cudaMemset(dB, 0, mb));
    CUDA_CHECK(cudaMemset(dI, 0, tb));

    matmulNaive     <<<dim3(N/16, N/16), dim3(16, 16)>>>(N, dA, dB, dC);
    tiled32         <<<dim3(N/T, N/T),   dim3(T, T)>>>  (N, dA, dB, dC);
    tiled32Swapped  <<<dim3(N/T, N/T),   dim3(T, T)>>>  (N, dA, dB, dC);
    transposeTile   <<<dim3(NT/TILE, NT/TILE), dim3(TILE, ROWS)>>>(NT, dI, dO);
    transposeTilePad<<<dim3(NT/TILE, NT/TILE), dim3(TILE, ROWS)>>>(NT, dI, dO);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());
    printf("kernels: รันครบ 5 kernel (matmul N = %d, transpose N = %d)\n", N, NT);

    CUDA_CHECK(cudaFree(dA)); CUDA_CHECK(cudaFree(dB)); CUDA_CHECK(cudaFree(dC));
    CUDA_CHECK(cudaFree(dI)); CUDA_CHECK(cudaFree(dO));
    return 0;
}
