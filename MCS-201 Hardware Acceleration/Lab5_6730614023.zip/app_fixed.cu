/* app_fixed.cu — เวอร์ชันที่ท่านต้องแก้ ผลลัพธ์ (checksum) ต้องเท่ากับ app.cu ทุกหลัก
   เติม TODO (1)–(4) โครงของลูปและ kernel ให้มาแล้ว */
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <nvtx3/nvToolsExt.h>

#define CUDA_CHECK(call)                                        \
  do {                                                          \
    cudaError_t err = (call);                                   \
    if (err != cudaSuccess) {                                   \
      fprintf(stderr, "CUDA %s:%d: %s\n", __FILE__, __LINE__,   \
              cudaGetErrorString(err));                         \
      exit(EXIT_FAILURE);                                       \
    }                                                           \
  } while (0)

const int FRAMES = 16;
const int NPIX   = 1 << 22;
const int NS     = 3;                        /* จำนวน stream = จำนวนช่อง (slot) ของบัฟเฟอร์ */

__global__ void normalize(int n, const float *in, float *out, float mean, float inv) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) out[i] = (in[i] - mean) * inv;
}
__global__ void gammaClamp(int n, float *x, float g) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) x[i] = powf(fminf(fmaxf(x[i], 0.0f), 1.0f), g);
}

static void fillFrame(float *h, int f) {
    for (int i = 0; i < NPIX; i++) h[i] = (float)((i * 7 + f * 13) % 1000);
}
static double checksum(const float *h) {
    double s = 0.0;
    for (int i = 0; i < NPIX; i++) s += h[i];
    return s;
}

int main() {
    size_t bytes = (size_t)NPIX * sizeof(float);
    double sums[FRAMES];

    nvtxRangePushA("init");
    CUDA_CHECK(cudaFree(0));

    float *h_in[NS], *h_out[NS], *d_in[NS], *d_out[NS];
    cudaStream_t st[NS];
    for (int s = 0; s < NS; s++) {
        /* TODO (1): จอง h_in[s] และ h_out[s] เป็น pinned memory (ไม่ใช่ malloc) */
        CUDA_CHECK(cudaMallocHost((void**)&h_in[s], bytes));
        CUDA_CHECK(cudaMallocHost((void**)&h_out[s], bytes));

        /* TODO (2): จอง d_in[s] และ d_out[s] ครั้งเดียวตรงนี้ — ห้ามจองในลูปเฟรม */
        CUDA_CHECK(cudaMalloc(&d_in[s], bytes));
        CUDA_CHECK(cudaMalloc(&d_out[s], bytes));

        CUDA_CHECK(cudaStreamCreate(&st[s]));
    }
    nvtxRangePop();

    auto t0 = std::chrono::steady_clock::now();
    for (int f = 0; f < FRAMES; f++) {
        int s = f % NS;
        nvtxRangePushA("frame");

        /* TODO (3): ก่อนใช้บัฟเฟอร์ช่อง s ซ้ำ ต้องรอให้งานเก่าของช่องนี้เสร็จ
           ให้รอเฉพาะ stream st[s] เท่านั้น — ห้ามใช้ cudaDeviceSynchronize()  */
        CUDA_CHECK(cudaStreamSynchronize(st[s]));

        if (f >= NS) {
            nvtxRangePushA("cpu: checksum");
            sums[f - NS] = checksum(h_out[s]);
            nvtxRangePop();
        }

        nvtxRangePushA("cpu: fill");
        fillFrame(h_in[s], f);
        nvtxRangePop();

        /* TODO (4a): คัดลอก h_in[s] -> d_in[s] แบบ async บน stream st[s] */
        CUDA_CHECK(cudaMemcpyAsync(d_in[s], h_in[s], bytes, cudaMemcpyHostToDevice, st[s]));

        normalize <<<(NPIX + 255) / 256, 256, 0, st[s]>>>(NPIX, d_in[s], d_out[s],
                                                          500.0f, 1.0f / 1000.0f);
        gammaClamp<<<(NPIX + 255) / 256, 256, 0, st[s]>>>(NPIX, d_out[s], 1.0f / 2.2f);
        CUDA_CHECK(cudaGetLastError());
        /* TODO (4b): คัดลอก d_out[s] -> h_out[s] แบบ async บน stream st[s] */
        CUDA_CHECK(cudaMemcpyAsync(h_out[s], d_out[s], bytes, cudaMemcpyDeviceToHost, st[s]));


        nvtxRangePop();
    }
    /* เก็บผลของ NS เฟรมสุดท้าย */
    for (int f = (FRAMES > NS ? FRAMES - NS : 0); f < FRAMES; f++) {
        int s = f % NS;
        CUDA_CHECK(cudaStreamSynchronize(st[s]));
        sums[f] = checksum(h_out[s]);
    }
    auto t1 = std::chrono::steady_clock::now();

    double total = 0.0;
    for (int f = 0; f < FRAMES; f++) total += sums[f];
    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    printf("app_fixed : %d เฟรม  %8.1f ms  (%.2f ms/เฟรม)  checksum = %.6e\n",
           FRAMES, ms, ms / FRAMES, total);

    for (int s = 0; s < NS; s++) {
        CUDA_CHECK(cudaFreeHost(h_in[s])); CUDA_CHECK(cudaFreeHost(h_out[s]));
        CUDA_CHECK(cudaFree(d_in[s]));     CUDA_CHECK(cudaFree(d_out[s]));
        CUDA_CHECK(cudaStreamDestroy(st[s]));
    }
    return 0;
}
