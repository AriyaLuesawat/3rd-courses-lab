/* rowmean.cu — ค่าเฉลี่ยรายแถวของเมทริกซ์ M x N (row-major)
   out[r] = (x[r][0] + x[r][1] + ... + x[r][N-1]) / N                        */
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cublas_v2.h>

#define CUDA_CHECK(call)                                        \
  do {                                                          \
    cudaError_t err = (call);                                   \
    if (err != cudaSuccess) {                                   \
      fprintf(stderr, "CUDA %s:%d: %s\n", __FILE__, __LINE__,   \
              cudaGetErrorString(err));                         \
      exit(EXIT_FAILURE);                                       \
    }                                                           \
  } while (0)

#define CUBLAS_CHECK(call)                                      \
  do {                                                          \
    cublasStatus_t st = (call);                                 \
    if (st != CUBLAS_STATUS_SUCCESS) {                          \
      fprintf(stderr, "cuBLAS %s:%d: status %d\n",              \
              __FILE__, __LINE__, (int)st);                     \
      exit(EXIT_FAILURE);                                       \
    }                                                           \
  } while (0)

const int M = 16384;                  /* จำนวนแถว   */
const int N = 1024;                   /* จำนวนคอลัมน์ (หารด้วย 128 ลงตัว) */

/* ---- v0: โค้ดตั้งต้น (ห้ามแก้) — หนึ่งเธรดต่อหนึ่งแถว ------------------- */
__global__ void rowMeanV0(int M, int N, const float *x, float *out) {
    int r = blockIdx.x * blockDim.x + threadIdx.x;
    if (r < M) {
        float s = 0.0f;
        for (int c = 0; c < N; c++) s += x[(size_t)r * N + c];
        out[r] = s / N;
    }
}
static void launchV0(const float *x, float *out) {
    rowMeanV0<<<(M + 31) / 32, 32>>>(M, N, x, out);
}

/* ---- v1: หนึ่ง warp ต่อหนึ่งแถว (ส่วนที่ต้องเขียนเอง) ------------------ */
__global__ void rowMeanV1(int M, int N, const float *x, float *out) {
    int warp = (blockIdx.x * blockDim.x + threadIdx.x) / 32;   /* = หมายเลขแถว */
    int lane = threadIdx.x % 32;
    if (warp >= M) return;                    /* ทั้ง warp ออกพร้อมกัน ไม่ divergent */

    const float *row = x + (size_t)warp * N;
    float s = 0.0f;
    /* TODO (1): วนอ่านทั้งแถวโดยให้ lane ที่ติดกันอ่านคอลัมน์ที่ติดกัน
       lane 0 อ่าน c = 0, 32, 64, ... · lane 1 อ่าน c = 1, 33, 65, ... แล้วสะสมใน s */
    for (int c = lane; c < N; c += 32) s += row[c];

    /* TODO (2): รวม s ของทั้ง 32 lane ด้วย __shfl_down_sync (offset 16, 8, 4, 2, 1) */
    for (int offset = 16; offset > 0; offset /= 2)
        s += __shfl_down_sync(0xffffffff, s, offset);

    /* TODO (3): lane 0 เขียนค่าเฉลี่ยของแถวลง out[warp] */
    if (lane == 0) out[warp] = s / N;

}
static void launchV1(const float *x, float *out) {
    /* TODO (4): เลือกจำนวนเธรดต่อ block แล้วคำนวณจำนวน block ให้ได้ M warp พอดี
       (หนึ่ง warp = หนึ่งแถว)                                                     */
    const int threads = 256;                 /* TODO (4) */
    const int blocks  = (M * 32 + threads - 1) / threads; /* TODO (4) */
    rowMeanV1<<<blocks, threads>>>(M, N, x, out);
}

/* ---- v2 (โบนัส ไม่บังคับ): v1 + โหลดทีละ float4 ---------------------------
   ถ้าไม่ทำโบนัส ให้แก้ launchV2 ด้านล่างให้เรียก launchV1 แทน (ค่าเริ่มต้น)          */
__global__ void rowMeanV2(int M, int N, const float *x, float *out) {
    int warp = (blockIdx.x * blockDim.x + threadIdx.x) / 32;
    int lane = threadIdx.x % 32;
    if (warp >= M) return;
    const float4 *row = reinterpret_cast<const float4*>(x + (size_t)warp * N);
    float s = 0.0f;
    /* โบนัส: เหมือน v1 แต่แต่ละ lane อ่าน float4 (16 ไบต์) ต่อครั้ง
       แถวหนึ่งมี N/4 ตัว float4                                              */
    for (int c = lane; c < N / 4; c += 32) {
        float4 v = row[c];
        s += v.x + v.y + v.z + v.w;
    }
    for (int offset = 16; offset > 0; offset /= 2)
        s += __shfl_down_sync(0xffffffff, s, offset);
    if (lane == 0) out[warp] = s / N;
}
static void launchV2(const float *x, float *out) {
    rowMeanV2<<<(M * 32 + 255) / 256, 256>>>(M, N, x, out); /* โบนัส: เปลี่ยนเป็น rowMeanV2<<<...>>> เมื่อเขียน v2 เสร็จ */
}

/* ---- อ้างอิงจากไลบรารี: cuBLAS SGEMV  out = (1/N) * X * ones ---------- */
static cublasHandle_t g_handle;
static float *g_ones;
static void launchCublas(const float *x, float *out) {
    const float alpha = 1.0f / N, beta = 0.0f;
    /* x (row-major M x N) ในมุมมอง column-major คือ X^T ขนาด N x M, lda = N
       ต้องการ X * ones = (X^T)^T * ones  ->  CUBLAS_OP_T                     */
    CUBLAS_CHECK(cublasSgemv(g_handle, CUBLAS_OP_T, N, M, &alpha,
                             x, N, g_ones, 1, &beta, out, 1));
}

static float timeIt(void (*launch)(const float*, float*), const float *dx, float *dout) {
    cudaEvent_t s, e; float ms = 0.0f;
    CUDA_CHECK(cudaEventCreate(&s)); CUDA_CHECK(cudaEventCreate(&e));
    launch(dx, dout);                                  /* warm-up */
    CUDA_CHECK(cudaEventRecord(s));
    for (int r = 0; r < 20; r++) launch(dx, dout);
    CUDA_CHECK(cudaEventRecord(e));
    CUDA_CHECK(cudaEventSynchronize(e));
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaEventElapsedTime(&ms, s, e));
    CUDA_CHECK(cudaEventDestroy(s)); CUDA_CHECK(cudaEventDestroy(e));
    return ms / 20.0f;
}

int main(int argc, char **argv) {
    /* ./rowmean        -> จับเวลาทุกเวอร์ชัน
       ./rowmean 0|1|2  -> รันเวอร์ชันเดียวครั้งเดียว (ใช้กับ ncu)             */
    int only = (argc > 1) ? atoi(argv[1]) : -1;
    size_t bytes = (size_t)M * N * sizeof(float);
    float *hx = (float*)malloc(bytes), *hout = (float*)malloc(M * sizeof(float));
    double *ref = (double*)malloc(M * sizeof(double));
    for (int r = 0; r < M; r++) {
        double s = 0.0;
        for (int c = 0; c < N; c++) {
            float v = (float)((r * 7 + c * 13) % 101) * 0.01f;
            hx[(size_t)r * N + c] = v;
            s += v;
        }
        ref[r] = s / N;
    }
    float *dx, *dout;
    CUDA_CHECK(cudaMalloc(&dx, bytes)); CUDA_CHECK(cudaMalloc(&dout, M * sizeof(float)));
    CUDA_CHECK(cudaMemcpy(dx, hx, bytes, cudaMemcpyHostToDevice));

    void (*launch[3])(const float*, float*) = {launchV0, launchV1, launchV2};
    if (only >= 0 && only <= 2) {
        launch[only](dx, dout);
        CUDA_CHECK(cudaGetLastError());
        CUDA_CHECK(cudaDeviceSynchronize());
        printf("rowmean: รัน v%d หนึ่งครั้ง\n", only);
        return 0;
    }

    CUBLAS_CHECK(cublasCreate(&g_handle));
    CUDA_CHECK(cudaMalloc(&g_ones, N * sizeof(float)));
    {
        float *h1 = (float*)malloc(N * sizeof(float));
        for (int c = 0; c < N; c++) h1[c] = 1.0f;
        CUDA_CHECK(cudaMemcpy(g_ones, h1, N * sizeof(float), cudaMemcpyHostToDevice));
        free(h1);
    }

    const char *name[4] = {"v0  thread/row, block 32 ", "v1  warp/row, block 256  ",
                           "v2  warp/row + float4    ", "cuBLAS SGEMV (อ้างอิง)   "};
    void (*all[4])(const float*, float*) = {launchV0, launchV1, launchV2, launchCublas};
    float t0 = 0.0f;
    printf("M = %d แถว  N = %d คอลัมน์  (%.0f MB)\n", M, N, bytes / 1e6);
    for (int w = 0; w < 4; w++) {
        CUDA_CHECK(cudaMemset(dout, 0, M * sizeof(float)));
        float ms = timeIt(all[w], dx, dout);
        if (w == 0) t0 = ms;
        CUDA_CHECK(cudaMemcpy(hout, dout, M * sizeof(float), cudaMemcpyDeviceToHost));
        double maxerr = 0.0;
        for (int r = 0; r < M; r++) maxerr = fmax(maxerr, fabs(hout[r] - ref[r]));
        printf("  %s : %7.3f ms   %6.1f GB/s   speedup %5.2fx   %s\n",
               name[w], ms, bytes / 1e9 / (ms / 1e3), t0 / ms,
               (maxerr < 1e-3) ? "[ผ่าน]" : "[ไม่ผ่าน]");
    }

    CUBLAS_CHECK(cublasDestroy(g_handle));
    CUDA_CHECK(cudaFree(g_ones)); CUDA_CHECK(cudaFree(dx)); CUDA_CHECK(cudaFree(dout));
    free(hx); free(hout); free(ref);
    return 0;
}
